#ifndef UTILS_H
#define UTILS_H
#include <string.h>
#include <malloc.h>

char* strmyreplace(char* texte,const char* cherche,const char* remplace);
#endif
