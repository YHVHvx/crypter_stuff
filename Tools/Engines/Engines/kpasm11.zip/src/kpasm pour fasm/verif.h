#include "kpasm.h"

int verification_semantique(linkedlist* transfos, linkedlist* lockeds);
void add_error(char* err);
