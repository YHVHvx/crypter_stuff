This example proposed by Jan Garcia is only for educational purpose. The BeaEngine library (BeaEngine.dll) included is surely not up-to-date. Just download the last package to replace this one by the last version.

BeatriX